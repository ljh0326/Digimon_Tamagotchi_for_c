#include "tools.h"
#include "screen.h"
#include "player.h"
#include "login.h"
#include "monster.h"

Player user;

int main()
{
  mainScreen();
}
